import paho.mqtt.client as mqtt

#############################
##  DB
import MySQLdb
# Open database connection
db = MySQLdb.connect("localhost","root","root","TESTDB" )
###########################


def checkTopics(topicName):
    sql = "SELECT TOPIC_LOCATION FROM TOPICS WHERE TOPIC_NAME='"+str(topicName)+"'"
    print "[QUERY] HIT : " + sql
    cursor = db.cursor()
    results=""
    try:
        cursor.execute(sql)
        passwordFromSQL = cursor.fetchall()
        for row in passwordFromSQL:
            results=row[0]
        return results
    except Exception as e:
        print str(e.message)
        return "cant access database"
        db.rollback()
    #db.close()
    cursor.close()



def on_connect(client, userdata, flags, rc):
    client.subscribe("#")
    print "[INFO] subsciption done"

def on_message(client, userdata, msg):
    print(msg.topic+" "+str(msg.payload))


client = mqtt.Client()
client.on_message = on_message
client.on_connect = on_connect

client.connect("localhost", 1883, 60)

client.loop_forever()

