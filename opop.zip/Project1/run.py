from flask import Flask,render_template,request
app=Flask(__name__)


##########
##  DB
import MySQLdb
# Open database connection
db = MySQLdb.connect("localhost","root","root","TESTDB" )


##################

@app.route("/")
def homePage():
    #return "this is home name"
    return render_template('index.html')

@app.route("/signup")
def signup():
    #return "this is home name"
    return render_template('signup.html')

@app.route("/submitreg",methods = ['POST', 'GET'])
def result():
   if request.method == 'POST':
      result = request.form
      #print result.get("pass")
      username=request.form.get("username")
      phone = request.form.get("phone")
      password = request.form.get("pass")
      print "INFO : " + str(username) + " : "+str(phone)+ " : " + str(password)
      sql = "INSERT INTO EMPLOYEE(FIRST_NAME,PHONE,PASS)VALUES ('"+username+"', '"+phone+"','"+password+"')"
      cursor = db.cursor()
      try:
          cursor.execute(sql)
          db.commit()
      except Exception as e:
          return render_template("signFail.html")
          db.rollback()
      #db.close()
      cursor.close()
      print "INFO : REGISTRATION : "+ username+" : "+phone+" : "+password
      return render_template("sign.html",result = result)


@app.route("/addtopic")
def addtopic():
    #return "this is home name"
    return render_template('topientry.html')

@app.route("/entrytopic",methods = ['POST', 'GET'])
def entrytopic():
   if request.method == 'POST':
      entrytopic = request.form
      topic=request.form.get("topicname")
      topicNumber = request.form.get("topicNumber")
      sql = "INSERT INTO TOPICS(TOPIC_NAME,TOPIC_NUMBER) VALUES ('"+topic+"','"+topicNumber+"')"
      cursor = db.cursor()
      try:
          cursor.execute(sql)
          db.commit()
      except Exception as e:
          #return "sorry topic already exist"
          print e
          db.rollback()
     # db.close()
      cursor.close()
      return render_template("entryTopic.html",topicName=topic)
      #return "topic is entered"

@app.route("/login")
def login():
    return render_template("loginForm.html")


@app.route("/checkTopics")
def checkTopics():
    sql = "SELECT * FROM TOPICS"
    print "QUERY HIT : " + sql
    cursor = db.cursor()
    results=""
    try:
        cursor.execute(sql)
        passwordFromSQL = cursor.fetchall()
        for row in passwordFromSQL:
            results=str(results)+str(row[0])+"<br>"
        return results
    except Exception as e:
        print str(e.message)
        return "cant access database"
        db.rollback()
    #db.close()
    cursor.close()


@app.route("/loginreport",methods = ['POST', 'GET'])
def loginreport():
    if request.method == 'POST':
        entrytopic = request.form
        username = request.form.get("username")
        password = request.form.get("password")
        print "[INFO]from login form : '"+ str(password)+"'"
        sql = "SELECT PASS FROM EMPLOYEE WHERE FIRST_NAME='" + str(username) + "'"
        sql2 = "SELECT TOPIC_NAME FROM TOPICS"
        print "[QUERY HIT] : " + sql
        cursor = db.cursor()
        try:
            cursor.execute(sql)
            passwordFromSQL=cursor.fetchall()
            for row in passwordFromSQL:
                passFromSQL=(row[0])
            print "[INFO]PASSWORD FETCHED : '"+ str(passFromSQL)+"'"
#            print passwordFromSQL
            cursor.close()
            cursor = db.cursor()
            cursor.execute(sql2)
            tops=cursor.fetchall()
            cursor.close()
            #print tops
            if (password==passFromSQL):
                return render_template("loggedIn.html",topics=tops)
            else:
                return render_template("loggedInFail.html")
        except Exception as e:
            # return "sorry topic already exist"
            print "[INFO]DB OPERATIONS"
            print e
            return render_template("loggedInFail.html")
            db.rollback()
        #db.close()

        # return render_template("entrytopic.html",result = result)


@app.route('/route/<code>')
def route(code):
    print code
    return render_template("sortedRoute.html",sortedRoute=code)


if __name__=="__main__":
    app.run(debug=True)
